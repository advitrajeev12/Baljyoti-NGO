import React from 'react'
import "./About.css"

const About = () => {
  return (
    <div className='inter123'>
    <div className='intervetion1'>
        <h2>.</h2>
        <div className='inter121'>
            <h2>1.VISION</h2>

        </div>
        <div className='inter212'>
<p>•Implementation of a core line-up for the products
made by Artisans, to be sold in a good platform.</p>
<p>•Establish a good livelihood income, which would both
serve: the Artisans and the Handicraft Sector. </p>
<p>•Building a sense of Leadership quality in the SHGs (Self
Help Group), SO that they can run their small scale business
by their own in their future</p>

        </div>
     
    </div>
    <div className='intervetion1'>
    
        <div className='inter312'>
            <h2>2.MISSION</h2>

        </div>
        <div className='inter412'>
      <p>•Bring back life into the extincting crafts of India.</p>
<p>•Help at least 300 families each year to rise them from their poverty
level.</p>
<p>•Sustain these families with craft bases and let them relive a basic
exposure to the modern World.</p>
<p>•Empower women where it is needed. 
</p>

        </div>
     
    </div>

    <div className='intervetion1'>
    
    <div className='inter512'>
        <h2>3.OBJECTIVE</h2>
    </div>
    <div className='inter612'>
   <p> •To provide customers with the type of products they want.</p>
<p>•Profit Margin for Artisans to be higher as compared to normal wages.</p>
<p>•Involve rural area in business sector, through intervention
in textile and Handicraft sector.</p>
<p>•Women empowerment to be the first priority, i:e to bring
them forward from the Taboo they face.</p>
    </div>
 
</div>

    </div>
  )
}
export default About;